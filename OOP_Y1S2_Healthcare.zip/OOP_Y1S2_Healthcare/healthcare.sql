-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 02, 2025 at 09:10 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE IF NOT EXISTS `appointment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` int NOT NULL,
  `pname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `did` int NOT NULL,
  `dname` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `dept` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_patient_user` (`pid`),
  KEY `fk_docctor_id` (`did`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `pid`, `pname`, `email`, `did`, `dname`, `date`, `time`, `dept`, `status`) VALUES
(11, 3, 'sana', 'sana@gmail.com', 2, 'Dr.Shiva', '2025-02-01', '2.00 PM', 'Dental', 'Confirmed');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
CREATE TABLE IF NOT EXISTS `bill` (
  `bill_pk` int NOT NULL AUTO_INCREMENT,
  `billId` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `billDate` varchar(50) NOT NULL,
  `totalPaid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`bill_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bill_pk`, `billId`, `billDate`, `totalPaid`) VALUES
(1, 'Bill-582339972201700', '02-02-2025', '69000'),
(2, 'Bill-601159652696000', '03-02-2025', '34500');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
CREATE TABLE IF NOT EXISTS `doctor` (
  `doctorid` int NOT NULL AUTO_INCREMENT,
  `doctorname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contactno` varchar(15) NOT NULL,
  `specialization` varchar(255) NOT NULL,
  PRIMARY KEY (`doctorid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctorid`, `doctorname`, `email`, `contactno`, `specialization`) VALUES
(1, 'Dr.Saman', 'saman@gmail.com', '0123456789', 'Neurology'),
(2, 'Dr.Shiva', 'Shiva@gmail.com', '5648219730', 'cardiology');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

DROP TABLE IF EXISTS `medicine`;
CREATE TABLE IF NOT EXISTS `medicine` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `medicine_id` varchar(10) NOT NULL,
  `expiry_date` varchar(20) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`id`, `name`, `medicine_id`, `expiry_date`, `quantity`, `price`) VALUES
(1, 'Asprin', '23', '07-02-2025', '65', '2300');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `age` int NOT NULL,
  `gender` varchar(8) NOT NULL,
  `contact` int NOT NULL,
  `email` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `bloodtype` varchar(4) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `name`, `age`, `gender`, `contact`, `email`, `dob`, `bloodtype`, `address`) VALUES
(3, 'Sithara', 26, 'Female', 123957648, 'sithara@gmail.com', '1996-02-29', 'B+', 'Colombo'),
(4, 'John', 25, 'Male', 456198732, 'John@gmail.com', '2000-12-13', 'A+', 'Colombo'),
(5, 'Ann', 45, 'Female', 1597532468, 'ann@gmail.com', '1980-08-17', 'B+', 'Gampaha'),
(6, 'Sana', 50, 'Female', 123456789, 'sana@gmail.com', '1975-02-11', 'B+', 'Ragama'),
(7, 'Seeths', 18, 'Female', 781245936, 'seetha@gmail.com', '2006-06-11', 'O+', 'kalutara');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
CREATE TABLE IF NOT EXISTS `schedule` (
  `scheduleid` int NOT NULL AUTO_INCREMENT,
  `doctorid` int NOT NULL,
  `doctorname` varchar(100) NOT NULL,
  `eventname` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(100) NOT NULL,
  PRIMARY KEY (`scheduleid`),
  KEY `fk_doctor_id` (`doctorid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`scheduleid`, `doctorid`, `doctorname`, `eventname`, `date`, `time`) VALUES
(1, 1, 'Dr.Saman', 'therapy', '2025-02-07', '2:00 AM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `type`) VALUES
(3, 'Hasna', 'admin123', 'Admin'),
(4, 'nimal', 'nimalrep123', 'Receptionist'),
(5, 'sara', 'sara123', 'Pharmacist'),
(6, 'sarath', 'sarath123', 'Doctor');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
