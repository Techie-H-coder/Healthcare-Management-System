
package view;
import java.sql.Connection;
import java.sql.PreparedStatement;
import controllers.connect;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import util.usersession;


public class DoctorScheduleView extends javax.swing.JFrame {

    
    Connection conn = null; 
    PreparedStatement pst = null;
    ResultSet rs=null;
    
    
    public DoctorScheduleView() {
        initComponents();
        conn=connect.connect();
        tableload();
    }
    
     //THIS SELECTS ALL THE DATA FROM DB AND DISPLAYS IT
    public void tableload() {
    try {
        
        String sql = "SELECT scheduleid AS 'Schedule ID', doctorname AS 'Doctor Name', eventname AS 'Event Name', date AS 'Date', time AS 'Time' " +
                     "FROM schedule " +
                     "ORDER BY date ASC, time ASC"; 

        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();
        scheduletable.setModel(DbUtils.resultSetToTableModel(rs));
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_eventname = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_docname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btn_add = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel7 = new javax.swing.JLabel();
        txt_search = new javax.swing.JTextField();
        txt_date = new com.toedter.calendar.JDateChooser();
        txt_time = new javax.swing.JComboBox<>();
        btn_delete = new javax.swing.JButton();
        txt_timem = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        btn_clear = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        scheduletable = new javax.swing.JTable();
        btn_exit = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txt_scheduleid = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(java.awt.Color.darkGray);

        jPanel2.setBackground(new java.awt.Color(33, 33, 37));

        jPanel1.setBackground(new java.awt.Color(33, 33, 37));

        jLabel2.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Full Name:");

        txt_eventname.setBackground(new java.awt.Color(18, 13, 49));
        txt_eventname.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txt_eventname.setForeground(java.awt.Color.white);
        txt_eventname.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 1)));
        txt_eventname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_eventnameActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Event Name");

        txt_docname.setBackground(new java.awt.Color(18, 13, 49));
        txt_docname.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txt_docname.setForeground(java.awt.Color.white);
        txt_docname.setText("Doctor Name");
        txt_docname.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 1)));
        txt_docname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_docnameActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel4.setForeground(java.awt.Color.white);
        jLabel4.setText("Date: ");

        jLabel6.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel6.setForeground(java.awt.Color.white);
        jLabel6.setText("Time");

        btn_add.setBackground(java.awt.Color.green);
        btn_add.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btn_add.setText("Add ");
        btn_add.setAlignmentY(0.0F);
        btn_add.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        btn_add.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });

        btn_update.setBackground(java.awt.Color.orange);
        btn_update.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btn_update.setText("Update");
        btn_update.setAlignmentY(0.0F);
        btn_update.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        btn_update.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_updateMouseEntered(evt);
            }
        });
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel7.setForeground(java.awt.Color.white);
        jLabel7.setText("Search Doctor's Schedule : ");

        txt_search.setText("Doctor/Event/ID");
        txt_search.setToolTipText("Doctor/Event/ID");
        txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_searchKeyReleased(evt);
            }
        });

        txt_time.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "12:00", "1:00", "2:00", "3:00", "4:00", "5:00", "6:00", "7:00", "8:00", "9:00", "10:00", "11:00", " " }));

        btn_delete.setBackground(java.awt.Color.red);
        btn_delete.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btn_delete.setText("Remove");
        btn_delete.setAlignmentY(0.0F);
        btn_delete.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        btn_delete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        txt_timem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AM", "PM", " " }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1)
                        .addGap(152, 152, 152))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(34, 34, 34)
                                .addComponent(txt_docname, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel6)
                                        .addComponent(jLabel4))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(txt_date, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(txt_time, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(9, 9, 9)
                                            .addComponent(txt_timem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(18, 18, 18)
                                    .addComponent(txt_eventname, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btn_add, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txt_docname, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txt_eventname, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txt_time)
                            .addComponent(txt_timem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_date, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_add, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(btn_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(81, 81, 81))
        );

        jLabel1.setFont(new java.awt.Font("Century Gothic", 1, 48)); // NOI18N
        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Doctor Schedule");

        btn_clear.setBackground(java.awt.Color.lightGray);
        btn_clear.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btn_clear.setText("Clear");
        btn_clear.setAlignmentY(0.0F);
        btn_clear.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        btn_clear.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });

        scheduletable.setBackground(new java.awt.Color(18, 13, 49));
        scheduletable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        scheduletable.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N
        scheduletable.setForeground(java.awt.Color.white);
        scheduletable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ScheduleID", "Doctor's Name", "Event's Name", "Date", "Time"
            }
        ));
        scheduletable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                scheduletableMouseClicked(evt);
            }
        });
        scheduletable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                scheduletableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(scheduletable);

        btn_exit.setBackground(java.awt.Color.black);
        btn_exit.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btn_exit.setForeground(java.awt.Color.white);
        btn_exit.setText("Exit");
        btn_exit.setAlignmentY(0.0F);
        btn_exit.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        btn_exit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel5.setForeground(java.awt.Color.white);
        jLabel5.setText("Schedule ID");

        txt_scheduleid.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        txt_scheduleid.setForeground(java.awt.Color.white);
        txt_scheduleid.setText("ID");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 483, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(114, 114, 114)
                        .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(txt_scheduleid, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 923, Short.MAX_VALUE)
                .addGap(50, 50, 50))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(362, 362, 362)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addGap(40, 40, 40)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_scheduleid))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(50, 50, 50))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_docnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_docnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_docnameActionPerformed

    private void btn_updateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_updateMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_updateMouseEntered

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
    update();        
    tableload();// TODO add your handling code here:
    
    }//GEN-LAST:event_btn_updateActionPerformed

    private void txt_eventnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_eventnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_eventnameActionPerformed
    
    //<------------------------------------------ADDDD DATAAA---------------------------------------------->
    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
    String doctorname = txt_docname.getText();
    String eventname = txt_eventname.getText();
    String time = (String) txt_time.getSelectedItem();
    String timem = (String) txt_timem.getSelectedItem();
    String timet = time + " " + timem; 
    
    //GETTINGG DAATEEE
    java.util.Date selectedDate = txt_date.getDate(); 
    if (selectedDate == null) {
        JOptionPane.showMessageDialog(null, "Please select a date.");
        return; // Exit the method if no date is selected
    }
    
    java.sql.Date sqlDate = new java.sql.Date(selectedDate.getTime()); // Convert to SQL Date

    // Check if the selected date is in the past
    java.sql.Date currentDate = new java.sql.Date(System.currentTimeMillis()); // Get current date
    if (sqlDate.before(currentDate)) {
        JOptionPane.showMessageDialog(null, "The selected date must be after the current date.");
        return; 
    }

    if (doctorname.isEmpty() || eventname.isEmpty() || time.isEmpty() || timem.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill in all fields.");
        return; // Exit the method if any field is empty
    }

    // Variable to hold doctor ID
    int doctorid = -1; 

    // Check if the doctor exists and retrieve the doctor ID
    try {
        String checkDoctorSql = "SELECT doctorid FROM doctor WHERE doctorname = '" + doctorname + "'";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(checkDoctorSql);

        if (rs.next()) {
            doctorid = rs.getInt("doctorid"); // Get the doctor ID
        } else {
            JOptionPane.showMessageDialog(null, "Doctor not found. Please check the name.");
            return; 
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error checking doctor: " + e.getMessage());
        return; 
    }

    // Check Whether the doctor have more shcedules at the same time
    try {
        String checkScheduleSql = "SELECT * FROM schedule WHERE doctorid = " + doctorid + " AND date = '" + sqlDate + "' AND time = '" + timet + "'";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(checkScheduleSql);

        if (rs.next()) {
            JOptionPane.showMessageDialog(null, "This doctor is already scheduled at this time.");
            return; 
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error checking schedule: " + e.getMessage());
        return; 
    }

    
    try {
        String sql = "INSERT INTO schedule (doctorid, doctorname, eventname, date, time) VALUES (" 
                     + doctorid + ", '" + doctorname + "', '" + eventname + "', '" 
                     + sqlDate + "', '" + timet + "')";
        Statement stmt = conn.createStatement();
        stmt.executeUpdate(sql); 
        JOptionPane.showMessageDialog(null, "Inserted Successfully");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error with Inserting: " + e.getMessage());
    }
    
    tableload();
    clear();
    }//GEN-LAST:event_btn_addActionPerformed

    private void scheduletableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_scheduletableKeyReleased
        tabledata();        // TODO add your handling code here:
    }//GEN-LAST:event_scheduletableKeyReleased

    private void scheduletableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_scheduletableMouseClicked
        tabledata();        // TODO add your handling code here:
    }//GEN-LAST:event_scheduletableMouseClicked

    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
    clear();        // TODO add your handling code here:
    }//GEN-LAST:event_btn_clearActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        String id=txt_scheduleid.getText();
        if(id!="ID"){
        int check = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete Event with ID '"+id+"'");
        
        if(check==0){
            try {
                String sql="DELETE from schedule WHERE scheduleid='"+id+"'";
                pst=conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Deleted Successfully");
                clear();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error Deleting");
            }
        }
        tableload();}
        else{
            JOptionPane.showMessageDialog(null, "No Record has been chosen");
        }        
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_searchKeyReleased
        search();        
    }//GEN-LAST:event_txt_searchKeyReleased

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
        this.dispose();
        Receptionistpanel rp = new Receptionistpanel();
        Doctorpanel dr=new Doctorpanel();
        String usertype =usersession.getUserType();
        if(usertype.equals("Receptionist")){
        rp.setVisible(true);
        }else if(usertype.equals("Doctor")){
        dr.setVisible(true);
        }
    }//GEN-LAST:event_btn_exitActionPerformed

    //<--------------------------------------------------------------------------------------------------------------->
    
    //<------------------------------------THIS SHOWS THE SELECTED DATA IN FIELDS---------------------------------------->
   public void tabledata() {
    int r = scheduletable.getSelectedRow();
    
    
    if (r >= 0) {
        String sid = scheduletable.getValueAt(r, 0).toString();
        String dname = scheduletable.getValueAt(r, 1).toString();
        String eventname = scheduletable.getValueAt(r, 2).toString();
        String date = scheduletable.getValueAt(r, 3).toString();
        String time = scheduletable.getValueAt(r, 4).toString();
        
        
        txt_scheduleid.setText(sid);
        txt_docname.setText(dname);
        txt_eventname.setText(eventname);
        
        // Parse the date string and set it in the JDateChooser
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
            java.util.Date parsedDate = dateFormat.parse(date);
            txt_date.setDate(parsedDate); 
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Error parsing date: " + e.getMessage());
        }
        
        
        String[] timeParts = time.split(" "); 
        if (timeParts.length == 2) {
            String hour = timeParts[0]; 
            String amPm = timeParts[1]; 
            
            
            txt_time.setSelectedItem(hour);
            
            txt_timem.setSelectedItem(amPm);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Please select a row from the table.");
    }
}
   
   public void update() {
    String sid = txt_scheduleid.getText();
    String doctorname = txt_docname.getText();
    String eventname = txt_eventname.getText();
    String time = (String) txt_time.getSelectedItem();
    String timem = (String) txt_timem.getSelectedItem();
    String timet = time + " " + timem; 
    
    // Get the date from the JDateChooser
    java.util.Date selectedDate = txt_date.getDate(); 
    if (selectedDate == null) {
        JOptionPane.showMessageDialog(null, "Please select a date.");
        return; 
    }
    
    java.sql.Date sqlDate = new java.sql.Date(selectedDate.getTime()); // Convert to SQL Date

    
    if (sid.equals("ID")) {
        JOptionPane.showMessageDialog(null, "No record has been chosen");
        return; // Exit if no record is chosen
    }

    // Check if any fields are empty
    if (doctorname.isEmpty() || eventname.isEmpty() || time.isEmpty() || timem.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill in all fields.");
        return; 
    }

    // Variable to hold doctor ID
    int doctorid = -1;

    // Check if the doctor exists and retrieve the doctor ID
    try {
        String checkDoctorSql = "SELECT doctorid FROM doctor WHERE doctorname = ?";
        pst = conn.prepareStatement(checkDoctorSql);
        pst.setString(1, doctorname);
        
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            doctorid = rs.getInt("doctorid"); // Get the doctor ID
        } else {
            JOptionPane.showMessageDialog(null, "Doctor not found. Please check the name.");
            return; // Exit if the doctor does not exist
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error checking doctor: " + e.getMessage());
        return; // Exit on error
    }

    // Check for scheduling conflicts excluding the current sid
    try {
        String checkScheduleSql = "SELECT * FROM schedule WHERE doctorid = ? AND date = ? AND time = ? AND scheduleid != ?";
        pst = conn.prepareStatement(checkScheduleSql);
        pst.setInt(1, doctorid);
        pst.setDate(2, sqlDate);
        pst.setString(3, timet);
        pst.setString(4, sid); // Exclude the current record from the check
        
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(null, "This doctor is already scheduled at this time.");
            return; 
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error checking schedule: " + e.getMessage());
        return; // Exit on error
    }

    // Now update the event in the schedule table
    try {
        String sql = "UPDATE schedule SET doctorid = ?, doctorname = ?, eventname = ?, date = ?, time = ? WHERE scheduleid = ?";
        pst = conn.prepareStatement(sql);
        
        // Set parameters
        pst.setInt(1, doctorid);
        pst.setString(2, doctorname);
        pst.setString(3, eventname);
        pst.setDate(4, sqlDate);
        pst.setString(5, timet);
        pst.setString(6, sid);
        
        pst.executeUpdate(); 
        JOptionPane.showMessageDialog(null, "Updated Successfully");
        clear();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error updating: " + e.getMessage());
    }
}
   
   //<------------------------TO CLEARRRRR------------------------------------->
   public void clear() {
   
    txt_scheduleid.setText("ID");
    txt_docname.setText("");
    txt_eventname.setText("");
    txt_search.setText("Doctor/Event Name");

    
    txt_date.setDate(null); 

    
    txt_time.setSelectedIndex(-1);
    txt_timem.setSelectedIndex(-1); 

}
   //<-----------SEARCHH UPPP EVENt NAMEE-------------------------->
   public void search(){
        String search=txt_search.getText();
        
        try {
            String sql="SELECT scheduleid AS 'Schedule ID',doctorname AS 'Doctor Name',eventname AS 'Event Name',Date AS 'Date',time AS Time FROM schedule WHERE eventname LIKE '%"+search+"%' OR doctorname LIKE '%"+search+"%' OR scheduleid LIKE '%"+search+"%'";
            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
            scheduletable.setModel(DbUtils.resultSetToTableModel(rs));
             
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DoctorScheduleView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DoctorScheduleView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DoctorScheduleView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DoctorScheduleView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DoctorScheduleView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_add;
    private javax.swing.JButton btn_clear;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_exit;
    private javax.swing.JButton btn_update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable scheduletable;
    private com.toedter.calendar.JDateChooser txt_date;
    private javax.swing.JTextField txt_docname;
    private javax.swing.JTextField txt_eventname;
    private javax.swing.JLabel txt_scheduleid;
    private javax.swing.JTextField txt_search;
    private javax.swing.JComboBox<String> txt_time;
    private javax.swing.JComboBox<String> txt_timem;
    // End of variables declaration//GEN-END:variables
}
