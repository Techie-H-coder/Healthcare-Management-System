package view;

import controllers.connect;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import util.usersession;

public class patientinfo extends javax.swing.JFrame {

    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    public patientinfo() {
        initComponents();
        conn = connect.connect();
        tableload();
    }

    //tableload()
    public void tableload() {

        try {
            String sql = "SELECT id AS PID,name AS PNAME,age AS AGE,gender AS GENDER,contact AS CONTACT,email AS EMAIL,dob AS DOB,bloodtype AS BLOOD_GROUP,address AS ADDRESS FROM patient";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            patientTable.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);

        }
    }

    //add()
    public void add() {
        if ( namebox.getText().isEmpty() || agebox.getText().isEmpty() || contactbox.getText().isEmpty() || emailbox.getText().isEmpty() || dobbox.getDate() == null || btbox.getSelectedItem().toString().equals("Select") || namebox.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in all required fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Retrieve input values
        String pname = namebox.getText();
        String age = agebox.getText();
        String gender = genderbox.getSelectedItem().toString();
        String contactno = contactbox.getText();
        String email = emailbox.getText();
        Date dob = new Date(dobbox.getDate().getTime());
        String btype = btbox.getSelectedItem().toString();
        String address = addressbox.getText();

        // Validate contact number
        if (!contactno.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(rootPane, "Please enter a valid 10-digit contact number.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int contact = Integer.parseInt(contactno);
        int page = Integer.parseInt(age);
        // Check if patient ID already exists
        if (recordExists("patient", "contact", contact)) {
            JOptionPane.showMessageDialog(rootPane, "A patient with this ID already exists.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insert patient record
        String sql = "INSERT INTO patient (name, age, gender, contact, email, dob, bloodtype, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, pname);
            pst.setInt(2, page);
            pst.setString(3, gender);
            pst.setInt(4, contact);
            pst.setString(5, email);
            pst.setDate(6, dob);
            pst.setString(7, btype);
            pst.setString(8, address);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(rootPane, "Patient record successfully inserted.", "Success", JOptionPane.INFORMATION_MESSAGE);
            tableload();
            clear();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error inserting patient record: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean recordExists(String table, String column, int id) {
        String sql = "SELECT 1 FROM " + table + " WHERE " + column + " = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, id);
            try (ResultSet rs = pst.executeQuery()) {
                return rs.next();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error checking record existence: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    //clear()
    public void clear() {
        searchbox.setText("");
        namebox.setText("");
        pidbox.setText("");
        agebox.setText("");
        genderbox.setSelectedIndex(0);
        contactbox.setText("");
        emailbox.setText("");
        dobbox.setDate(null);
        btbox.setSelectedIndex(0);
        addressbox.setText("");

    }

    //tabledata()
    public void tabledata() {

        int r = patientTable.getSelectedRow();
        String pid = patientTable.getValueAt(r, 0).toString();
        String pname = patientTable.getValueAt(r, 1).toString();
        String age = patientTable.getValueAt(r, 2).toString();
        String gender = patientTable.getValueAt(r, 3).toString();
        String contact = patientTable.getValueAt(r, 4).toString();
        String email = patientTable.getValueAt(r, 5).toString();
        String dob = patientTable.getValueAt(r, 6).toString();
        String btype = patientTable.getValueAt(r, 7).toString();
        String address = patientTable.getValueAt(r, 8).toString();

        pidbox.setText(pid);
        namebox.setText(pname);
        agebox.setText(age);
        genderbox.setSelectedItem(gender);
        contactbox.setText(contact);
        emailbox.setText(email);
        Date sqlDate = Date.valueOf(dob);
        dobbox.setDate(sqlDate);
        btbox.setSelectedItem(btype);
        addressbox.setText(address);

    }

    //search patient()
    public void search() {
        String srch = searchbox.getText();
        try {
            String sql = "SELECT * FROM patient WHERE name like '%" + srch + "%'  OR id like '" + srch + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            patientTable.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    //update patient()
    public void update() {
        if (namebox.getText().isEmpty() || agebox.getText().isEmpty() || contactbox.getText().isEmpty() || emailbox.getText().isEmpty() || dobbox.getDate() == null || btbox.getSelectedItem().toString().equals("Select") || addressbox.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in all required fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String pid = pidbox.getText();
        String pname = namebox.getText();
        String age = agebox.getText();
        String gender = genderbox.getSelectedItem().toString();
        String contact = contactbox.getText();
        String email = emailbox.getText();
        Date dob = new Date(dobbox.getDate().getTime());
        String btype = btbox.getSelectedItem().toString();
        String address = addressbox.getText();

        // Validate ID
        int patientid;
        try {
            patientid = Integer.parseInt(pid);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(rootPane, "Please enter a valid patient ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate contact number
        if (!contact.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(rootPane, "Please enter a valid 10-digit contact number.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int contactno = Integer.parseInt(contact);
        int Age = Integer.parseInt(age);

        // Check if patient exists
        if (!recordExists("patient", "id", patientid)) {
            JOptionPane.showMessageDialog(rootPane, "Patient ID does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Update patient record
        String sql = "UPDATE patient SET name=?, age=?, gender=?, contact=?, email=?, dob=?, bloodtype=?, address=? WHERE id=?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, pname);
            pst.setInt(2, Age);
            pst.setString(3, gender);
            pst.setInt(4, contactno);
            pst.setString(5, email);
            pst.setDate(6, dob);
            pst.setString(7, btype);
            pst.setString(8, address);
            pst.setInt(9, patientid);

            int rowsUpdated = pst.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(rootPane, "Patient record successfully updated.", "Success", JOptionPane.INFORMATION_MESSAGE);
                tableload();
                clear();
            } else {
                JOptionPane.showMessageDialog(rootPane, "Update failed! No matching ID found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error updating patient record: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    //delete patient()
    public void delete() {

        int check = JOptionPane.showConfirmDialog(null, "Do you want to delete?");

        if (check == JOptionPane.YES_OPTION) {
            String id = pidbox.getText().trim();

            if (id.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please Select the patient data !!!");
                return;
            }

            try {

                String sql = "DELETE FROM patient WHERE id = ?";
                pst = conn.prepareStatement(sql);
                pst.setString(1, id);
                int rowsAffected = pst.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Deleted successfully.");
                } else {
                    JOptionPane.showMessageDialog(null, "No record found with the given ID.", "Deletion Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
         tableload();
        clear();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        namebox = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        addressbox = new javax.swing.JTextField();
        pidbox = new javax.swing.JTextField();
        agebox = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        contactbox = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        emailbox = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        genderbox = new javax.swing.JComboBox<>();
        updatebtn = new javax.swing.JButton();
        clearbtn = new javax.swing.JButton();
        addbtn = new javax.swing.JButton();
        deletebtn = new javax.swing.JButton();
        dobbox = new com.toedter.calendar.JDateChooser();
        btbox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        patientTable = new javax.swing.JTable();
        exitbtn = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        searchbox = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Patient Manager");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 51));
        jLabel4.setText("Age");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 110, 20));
        jPanel2.add(namebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 130, 30));

        jLabel5.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 51));
        jLabel5.setText("Patient ID");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 110, 20));

        jLabel6.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 51));
        jLabel6.setText("Patient ID");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 110, 20));

        jLabel7.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 51));
        jLabel7.setText("Patient ID");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 110, 20));

        jLabel8.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 51));
        jLabel8.setText("Gender");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 110, 20));

        jLabel9.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 51));
        jLabel9.setText("Name");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 110, 20));
        jPanel2.add(addressbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 130, 30));
        jPanel2.add(pidbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 130, 30));
        jPanel2.add(agebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 130, 30));

        jLabel10.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 51));
        jLabel10.setText("Contact");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 110, 20));
        jPanel2.add(contactbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 130, 30));

        jLabel11.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 51));
        jLabel11.setText("Address");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 110, -1));
        jPanel2.add(emailbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, 130, 30));

        jLabel12.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 51));
        jLabel12.setText("Email");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 110, -1));

        jLabel13.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 51));
        jLabel13.setText("DOB");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 110, -1));

        jLabel14.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 51));
        jLabel14.setText("Blood Type");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 110, -1));

        genderbox.setFont(new java.awt.Font("Lucida Bright", 0, 14)); // NOI18N
        genderbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Male", "Female", "Other" }));
        jPanel2.add(genderbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, 130, 30));

        updatebtn.setBackground(new java.awt.Color(0, 102, 51));
        updatebtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        updatebtn.setForeground(new java.awt.Color(255, 255, 102));
        updatebtn.setText("UPDATE");
        updatebtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        jPanel2.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 400, 100, 40));

        clearbtn.setBackground(new java.awt.Color(153, 0, 0));
        clearbtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        clearbtn.setForeground(new java.awt.Color(255, 255, 102));
        clearbtn.setText("CLEAR");
        clearbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        clearbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearbtnActionPerformed(evt);
            }
        });
        jPanel2.add(clearbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 450, 100, 40));

        addbtn.setBackground(new java.awt.Color(0, 102, 51));
        addbtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        addbtn.setForeground(new java.awt.Color(255, 255, 102));
        addbtn.setText("ADD");
        addbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        addbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbtnActionPerformed(evt);
            }
        });
        jPanel2.add(addbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 100, 40));

        deletebtn.setBackground(new java.awt.Color(153, 0, 0));
        deletebtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        deletebtn.setForeground(new java.awt.Color(255, 255, 102));
        deletebtn.setText("DELETE");
        deletebtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        jPanel2.add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 100, 40));
        jPanel2.add(dobbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 260, 130, 30));

        btbox.setFont(new java.awt.Font("Lucida Bright", 0, 14)); // NOI18N
        btbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" }));
        jPanel2.add(btbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, 130, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 290, 540));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 255, 204));
        jLabel1.setText("Patient Information");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 20, 440, 40));

        patientTable.setBackground(new java.awt.Color(0, 204, 153));
        patientTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        patientTable.setForeground(new java.awt.Color(255, 255, 204));
        patientTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9"
            }
        ));
        patientTable.setSelectionBackground(new java.awt.Color(204, 255, 204));
        patientTable.setSelectionForeground(new java.awt.Color(0, 51, 51));
        patientTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                patientTableMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                patientTableMouseReleased(evt);
            }
        });
        patientTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                patientTableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(patientTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 80, 770, 300));

        exitbtn.setBackground(new java.awt.Color(204, 0, 0));
        exitbtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        exitbtn.setForeground(new java.awt.Color(255, 255, 0));
        exitbtn.setText("EXIT");
        exitbtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        exitbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbtnActionPerformed(evt);
            }
        });
        jPanel1.add(exitbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 430, 90, 40));

        jPanel3.setBackground(new java.awt.Color(0, 102, 153));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel3.setToolTipText("Enter patient name or patient ID");
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        searchbox.setToolTipText("Enter Patient name or patientID");
        searchbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchboxActionPerformed(evt);
            }
        });
        jPanel3.add(searchbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 171, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 420, 220, 60));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1120, 540));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbtnActionPerformed

        String usertype = usersession.getUserType();

        this.dispose();

        if (usertype.equals("Receptionist")) {
            new Receptionistpanel().setVisible(true);
        } else if (usertype.equals("Admin")) {
            new adminpanel().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Unknown user type.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_exitbtnActionPerformed

    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed
        update();
        clear();
    }//GEN-LAST:event_updatebtnActionPerformed

    private void clearbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearbtnActionPerformed
        clear();
    }//GEN-LAST:event_clearbtnActionPerformed

    private void addbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbtnActionPerformed
        add();
    }//GEN-LAST:event_addbtnActionPerformed

    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
        delete();
        clear();
    }//GEN-LAST:event_deletebtnActionPerformed

    private void searchboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchboxActionPerformed
        search();
    }//GEN-LAST:event_searchboxActionPerformed

    private void patientTableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_patientTableMouseReleased

    }//GEN-LAST:event_patientTableMouseReleased

    private void patientTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_patientTableKeyReleased
        tabledata();
    }//GEN-LAST:event_patientTableKeyReleased

    private void patientTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_patientTableMouseClicked
        tabledata();
    }//GEN-LAST:event_patientTableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(patientinfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(patientinfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(patientinfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(patientinfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new patientinfo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addbtn;
    private javax.swing.JTextField addressbox;
    private javax.swing.JTextField agebox;
    private javax.swing.JComboBox<String> btbox;
    private javax.swing.JButton clearbtn;
    private javax.swing.JTextField contactbox;
    private javax.swing.JButton deletebtn;
    private com.toedter.calendar.JDateChooser dobbox;
    private javax.swing.JTextField emailbox;
    private javax.swing.JButton exitbtn;
    private javax.swing.JComboBox<String> genderbox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField namebox;
    private javax.swing.JTable patientTable;
    private javax.swing.JTextField pidbox;
    private javax.swing.JTextField searchbox;
    private javax.swing.JButton updatebtn;
    // End of variables declaration//GEN-END:variables

}
