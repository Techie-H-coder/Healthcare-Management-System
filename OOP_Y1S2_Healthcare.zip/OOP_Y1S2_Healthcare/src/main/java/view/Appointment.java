package view;

import controllers.connect;
import java.awt.Component;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

public class Appointment extends javax.swing.JFrame {

    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    private Component JDialog;

    public Appointment() {
        initComponents();
        conn = connect.connect();
        tableload();
    }

    //tableload()
    public void tableload() {

        try {
            String sql = "SELECT id AS ID,pid AS PID,pname AS PNAME,email AS P_EMAIL,did AS DID,dname AS DNAME,date AS DATE,time AS TIME,dept AS DEPT,status AS STATUS FROM appointment";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            apptable.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);

        }
    }

    //add()
    public void add() {

        String pid = pidbox.getText();
        String pname = pnamebox.getText();
        String pemail = emailbox.getText();
        String did = didbox.getText();
        String dname = dnamebox.getText();
        String dept = deptbox.getText();
        Date date = new Date(datebox.getDate() != null ? datebox.getDate().getTime() : System.currentTimeMillis());
        String time = timebox.getSelectedItem().toString();
        String status = statusbox.getSelectedItem().toString();

        if (pid.isEmpty() || pname.isEmpty() || pemail.isEmpty() || did.isEmpty() || dname.isEmpty() || dept.isEmpty() || date == null || time.equals("Select") || status.equals("Select")) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in all required fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate doctor ID
        int patientid;
        int doctorid;
        try {
            doctorid = Integer.parseInt(did);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(rootPane, "Please enter a valid doctor ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check if patient exists
        patientid = Integer.parseInt(pid);
        if (!recordExists("patient", "id", patientid)) {
            JOptionPane.showMessageDialog(rootPane, "Patient ID does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check if doctor exists
        if (!recordExists("doctor", "doctorid", doctorid)) {
            JOptionPane.showMessageDialog(rootPane, "Doctor ID does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check if the doctor is already scheduled at the given date and time
        String checkSql = "SELECT COUNT(*) FROM appointment WHERE did = ? AND date = ? AND time = ?";
        try {
            pst = conn.prepareStatement(checkSql);
            pst.setInt(1, doctorid);
            pst.setDate(2, date);
            pst.setString(3, time);

            ResultSet rs = pst.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(rootPane, "Doctor is already scheduled at this time. Please choose a different time.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error checking doctor's schedule: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insert appointment record
        String sql = "INSERT INTO appointment (pid, pname, email, did, dname, date, time, dept, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            pst = conn.prepareStatement(sql);
            pst.setInt(1, patientid);
            pst.setString(2, pname);
            pst.setString(3, pemail);
            pst.setInt(4, doctorid);
            pst.setString(5, dname);
            pst.setDate(6, date);
            pst.setString(7, time);
            pst.setString(8, dept);
            pst.setString(9, status);

            pst.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Appointment successfully scheduled.", "Success", JOptionPane.INFORMATION_MESSAGE);
            tableload();
            clear();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error scheduling appointment: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    private boolean recordExists(String table, String column, int id) {
        String sql = "SELECT 1 FROM " + table + " WHERE " + column + " = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, id);
            try (ResultSet rs = pst.executeQuery()) {
                return rs.next();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error checking record existence: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    //clear()
    public void clear() {
        searchbox.setText("");
        idbox.setText("ID");
        pidbox.setText("");
        pnamebox.setText("");
        emailbox.setText("");
        didbox.setText("");
        dnamebox.setText("");
        deptbox.setText("");
        dnamebox.setText("");
        datebox.setDate(null);
        timebox.setSelectedIndex(0);
        statusbox.setSelectedIndex(0);

    }

    //tabledata()
    public void tabledata() {

        int r = apptable.getSelectedRow();
        String id = apptable.getValueAt(r, 0).toString();
        String pid = apptable.getValueAt(r, 1).toString();
        String pname = apptable.getValueAt(r, 2).toString();
        String pemail = apptable.getValueAt(r, 3).toString();
        String did = apptable.getValueAt(r, 4).toString();
        String dname = apptable.getValueAt(r, 5).toString();
        String dept = apptable.getValueAt(r, 8).toString();
        String date = apptable.getValueAt(r, 6).toString();
        String time = apptable.getValueAt(r, 7).toString();
        String Status = apptable.getValueAt(r, 9).toString();

        idbox.setText(id);
        pidbox.setText(pid);
        pnamebox.setText(pname);
        emailbox.setText(pemail);
        didbox.setText(did);
        dnamebox.setText(dname);
        deptbox.setText(dept);
        Date sqlDate = Date.valueOf(date);
        datebox.setDate(sqlDate);
        timebox.setSelectedItem(time);
        statusbox.setSelectedItem(Status);

    }

    //search()
    public void search() {
        String srch = searchbox.getText();
        try {
            String sql = "SELECT * FROM appointment WHERE pname like '%" + srch + "%'  OR id like '" + srch + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            apptable.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    //update()
    public void update() {
        if (idbox.getText().isEmpty() || pidbox.getText().isEmpty() || pnamebox.getText().isEmpty() || emailbox.getText().isEmpty() || didbox.getText().isEmpty() || dnamebox.getText().isEmpty() || deptbox.getText().isEmpty() || datebox.getDate() == null || timebox.getSelectedItem().toString().equals("Select") || statusbox.getSelectedItem().toString().equals("Select")) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in all required fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Retrieve input values
        int id = Integer.parseInt(idbox.getText());
        int pid = Integer.parseInt(pidbox.getText());
        String pname = pnamebox.getText();
        String pemail = emailbox.getText();
        int did = Integer.parseInt(didbox.getText());
        String dname = dnamebox.getText();
        String dept = deptbox.getText();
        Date date = new Date(datebox.getDate() != null ? datebox.getDate().getTime() : System.currentTimeMillis());
        String time = timebox.getSelectedItem().toString();
        String status = statusbox.getSelectedItem().toString();

        // Validate patient ID
        if (!isValidPatient(pid)) {
            JOptionPane.showMessageDialog(null, "Invalid Patient ID.");
            return;
        }

        // Validate doctor ID
        if (!isValidDoctor(did)) {
            JOptionPane.showMessageDialog(null, "Invalid Doctor ID.");
            return;
        }

        try {
            String sql = "UPDATE appointment SET pid=?, pname=?, email=?, did=?, dname=?, date=?, time=?, dept=?, status=? WHERE id=?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, pid);
            pst.setString(2, pname);
            pst.setString(3, pemail);
            pst.setInt(4, did);
            pst.setString(5, dname);
            pst.setDate(6, date);
            pst.setString(7, time);
            pst.setString(8, dept);
            pst.setString(9, status);
            pst.setInt(10, id);

            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Updated successfully!");
                tableload();
            } else {
                JOptionPane.showMessageDialog(null, "Update failed! No matching ID found.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

//check if patient ID is valid
    private boolean isValidPatient(int pid) {
        try {
            String sql = "SELECT COUNT(*) FROM patient WHERE id=?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, pid);
            rs = pst.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                return true;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error validating patient ID: " + e.getMessage());
        }
        return false;
    }

// check if doctor ID is valid
    private boolean isValidDoctor(int did) {
        try {
            String sql = "SELECT COUNT(*) FROM doctor WHERE doctorid=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, did);
            rs = pst.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                return true;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error validating doctor ID: " + e.getMessage());
        }
        return false;
    }

    //delete()
    public void delete() {

        int check = JOptionPane.showConfirmDialog(null, "Do you want to delete?");

        if (check == JOptionPane.YES_OPTION) {
            String id = idbox.getText().trim();

            if (id.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please Select the Appointment data !!!");
                return;
            }

            try {

                String sql = "DELETE FROM appointment WHERE id = ?";
                pst = conn.prepareStatement(sql);
                pst.setString(1, id);
                int rowsAffected = pst.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Deleted successfully.");
                } else {
                    JOptionPane.showMessageDialog(null, "No record found with the given ID.", "Deletion Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        // Refresh the table and clear input fields
        tableload();
        clear();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        searchbox = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        pidbox = new javax.swing.JTextField();
        deptbox = new javax.swing.JTextField();
        idbox = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        dnamebox = new javax.swing.JTextField();
        didbox = new javax.swing.JTextField();
        addbtn = new javax.swing.JButton();
        pnamebox = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        emailbox = new javax.swing.JTextField();
        clearbtn = new javax.swing.JButton();
        deletebtn = new javax.swing.JButton();
        statusbox = new javax.swing.JComboBox<>();
        datebox = new com.toedter.calendar.JDateChooser();
        timebox = new javax.swing.JComboBox<>();
        updatebtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        apptable = new javax.swing.JTable();
        exitbtn = new javax.swing.JButton();
        notifybtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Appointment");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(0, 102, 153));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        searchbox.setToolTipText("Enter Appointment ID or patient name");
        searchbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchboxActionPerformed(evt);
            }
        });
        jPanel3.add(searchbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 18, 171, -1));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 220, 60));

        jLabel2.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 51));
        jLabel2.setText("Doctor ID");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 120, 20));

        jLabel3.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 51));
        jLabel3.setText("ID ");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 40, 20));

        jLabel4.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 51));
        jLabel4.setText("Patient ID");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 110, 20));

        jLabel5.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 51));
        jLabel5.setText("Date");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 120, 20));

        jLabel6.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 51));
        jLabel6.setText("Email");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 240, 120, 20));

        jLabel7.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 51));
        jLabel7.setText("Department");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, 120, 20));

        jLabel8.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 51));
        jLabel8.setText("Doctor name");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 120, 20));

        jLabel10.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 51));
        jLabel10.setText("Time");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 120, 20));

        pidbox.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 12)); // NOI18N
        jPanel2.add(pidbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 150, 30));

        deptbox.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 12)); // NOI18N
        deptbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deptboxActionPerformed(evt);
            }
        });
        jPanel2.add(deptbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 140, 30));

        idbox.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 12)); // NOI18N
        jPanel2.add(idbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 90, 30));

        jLabel13.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 51));
        jLabel13.setText("Status");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 120, 20));

        dnamebox.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 12)); // NOI18N
        jPanel2.add(dnamebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 140, 30));

        didbox.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 12)); // NOI18N
        jPanel2.add(didbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 130, 30));

        addbtn.setBackground(new java.awt.Color(0, 153, 51));
        addbtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        addbtn.setForeground(new java.awt.Color(255, 255, 0));
        addbtn.setText("ADD");
        addbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        addbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbtnActionPerformed(evt);
            }
        });
        jPanel2.add(addbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 110, 40));

        pnamebox.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 12)); // NOI18N
        pnamebox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pnameboxActionPerformed(evt);
            }
        });
        jPanel2.add(pnamebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 190, 150, 30));

        jLabel9.setFont(new java.awt.Font("Microsoft Tai Le", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 51));
        jLabel9.setText("Patient name");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 170, 120, 20));

        emailbox.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 12)); // NOI18N
        jPanel2.add(emailbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, 150, 30));

        clearbtn.setBackground(new java.awt.Color(255, 255, 102));
        clearbtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        clearbtn.setForeground(new java.awt.Color(102, 0, 0));
        clearbtn.setText("CLEAR");
        clearbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        clearbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearbtnActionPerformed(evt);
            }
        });
        jPanel2.add(clearbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 400, 110, 40));

        deletebtn.setBackground(new java.awt.Color(255, 102, 51));
        deletebtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        deletebtn.setForeground(new java.awt.Color(255, 255, 0));
        deletebtn.setText("DELETE");
        deletebtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        jPanel2.add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 460, 110, 40));

        statusbox.setFont(new java.awt.Font("Lucida Bright", 0, 14)); // NOI18N
        statusbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Confirmed", "Pending", "Scheduled", "Cancelled", " ", " " }));
        statusbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                statusboxActionPerformed(evt);
            }
        });
        jPanel2.add(statusbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 410, 160, 30));
        jPanel2.add(datebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 330, 160, 30));

        timebox.setFont(new java.awt.Font("Lucida Bright", 0, 14)); // NOI18N
        timebox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "9.00 AM", "10.00 AM", "11.00 AM", "12.00 PM", "2.00 PM", "3.00 PM", "4.00 PM", "5.00 PM", "6.00 PM", "7.00 PM", "8.00 PM", " " }));
        jPanel2.add(timebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 370, 160, 30));

        updatebtn.setBackground(new java.awt.Color(0, 153, 51));
        updatebtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        updatebtn.setForeground(new java.awt.Color(255, 255, 0));
        updatebtn.setText("UPDATE");
        updatebtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        jPanel2.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 460, 110, 40));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 440, 520));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 255, 204));
        jLabel1.setText("Appointment Schedule");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, 310, 40));

        apptable.setBackground(new java.awt.Color(255, 255, 204));
        apptable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        apptable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9", "Title 10"
            }
        ));
        apptable.setGridColor(new java.awt.Color(0, 102, 102));
        apptable.setSelectionBackground(new java.awt.Color(204, 255, 255));
        apptable.setSelectionForeground(new java.awt.Color(0, 51, 51));
        apptable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                apptableMouseClicked(evt);
            }
        });
        apptable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                apptableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(apptable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 80, 820, 400));

        exitbtn.setBackground(new java.awt.Color(204, 0, 0));
        exitbtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        exitbtn.setForeground(new java.awt.Color(255, 255, 0));
        exitbtn.setText("EXIT");
        exitbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbtnActionPerformed(evt);
            }
        });
        jPanel1.add(exitbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 20, 90, 40));

        notifybtn.setBackground(new java.awt.Color(213, 11, 11));
        notifybtn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        notifybtn.setForeground(new java.awt.Color(255, 255, 255));
        notifybtn.setText("Notify patients");
        notifybtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notifybtnActionPerformed(evt);
            }
        });
        jPanel1.add(notifybtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 20, 160, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1330, 520));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbtnActionPerformed
        this.dispose();
        new Receptionistpanel().setVisible(true);
    }//GEN-LAST:event_exitbtnActionPerformed

    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
        delete();
    }//GEN-LAST:event_deletebtnActionPerformed

    private void addbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbtnActionPerformed
        add();

    }//GEN-LAST:event_addbtnActionPerformed

    private void deptboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deptboxActionPerformed

    }//GEN-LAST:event_deptboxActionPerformed

    private void statusboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_statusboxActionPerformed

    }//GEN-LAST:event_statusboxActionPerformed

    private void pnameboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pnameboxActionPerformed

    }//GEN-LAST:event_pnameboxActionPerformed

    private void apptableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_apptableMouseClicked
        tabledata();
    }//GEN-LAST:event_apptableMouseClicked

    private void apptableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_apptableKeyReleased
        tabledata();
    }//GEN-LAST:event_apptableKeyReleased

    private void searchboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchboxActionPerformed
        search();
    }//GEN-LAST:event_searchboxActionPerformed

    private void clearbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearbtnActionPerformed
        clear();
    }//GEN-LAST:event_clearbtnActionPerformed

    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed
        update();
    }//GEN-LAST:event_updatebtnActionPerformed

    private void notifybtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notifybtnActionPerformed

        int selectedRow = apptable.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a patient from the table!");
            return;
        }

        // Get data from the selected row
        int id = Integer.parseInt(apptable.getValueAt(selectedRow, 0).toString());
        int pid = Integer.parseInt(apptable.getValueAt(selectedRow, 1).toString());
        String patientName = apptable.getValueAt(selectedRow, 2).toString();
        String patientemail = apptable.getValueAt(selectedRow, 3).toString();
        int did = Integer.parseInt(apptable.getValueAt(selectedRow, 4).toString());
        String doctorName = apptable.getValueAt(selectedRow, 5).toString();
        String department = apptable.getValueAt(selectedRow, 6).toString();
        String date = apptable.getValueAt(selectedRow, 7).toString();
        String time = apptable.getValueAt(selectedRow, 8).toString();
        String status = apptable.getValueAt(selectedRow, 9).toString();

        // Send Email Notification
        Notify_patients.sendAppointmentConfirmation(patientemail, patientName, doctorName, date, time);

        // Show confirmation message
        JOptionPane.showMessageDialog(null, "Notification sent to " + patientName + " successfully!");

    }//GEN-LAST:event_notifybtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Appointment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addbtn;
    private javax.swing.JTable apptable;
    private javax.swing.JButton clearbtn;
    private com.toedter.calendar.JDateChooser datebox;
    private javax.swing.JButton deletebtn;
    private javax.swing.JTextField deptbox;
    private javax.swing.JTextField didbox;
    private javax.swing.JTextField dnamebox;
    private javax.swing.JTextField emailbox;
    private javax.swing.JButton exitbtn;
    private javax.swing.JTextField idbox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton notifybtn;
    private javax.swing.JTextField pidbox;
    private javax.swing.JTextField pnamebox;
    private javax.swing.JTextField searchbox;
    private javax.swing.JComboBox<String> statusbox;
    private javax.swing.JComboBox<String> timebox;
    private javax.swing.JButton updatebtn;
    // End of variables declaration//GEN-END:variables
}
