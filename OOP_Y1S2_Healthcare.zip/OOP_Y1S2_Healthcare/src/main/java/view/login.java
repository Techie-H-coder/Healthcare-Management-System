
package view;
import controllers.connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import util.usersession;


public class login extends javax.swing.JFrame {
    
    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    
    public login() {
        initComponents();
        conn = connect.connect();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        loginlbl = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        unamebox = new javax.swing.JTextField();
        pwbox = new javax.swing.JPasswordField();
        typebox = new javax.swing.JComboBox<>();
        cancelbtn = new javax.swing.JButton();
        loginbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Hopecare -Login");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        loginlbl.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        loginlbl.setForeground(new java.awt.Color(255, 255, 204));
        loginlbl.setText("Login");
        jPanel2.add(loginlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, 90, 30));

        jLabel1.setFont(new java.awt.Font("Cambria", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 153));
        jLabel1.setText("Type");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 70, 30));

        jLabel2.setFont(new java.awt.Font("Cambria", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 153));
        jLabel2.setText("Password");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 90, 30));

        jLabel3.setFont(new java.awt.Font("Cambria", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 153));
        jLabel3.setText("Username");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 100, 30));

        unamebox.setFont(new java.awt.Font("Lucida Bright", 0, 14)); // NOI18N
        unamebox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unameboxActionPerformed(evt);
            }
        });
        jPanel2.add(unamebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, 130, 30));

        pwbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pwboxActionPerformed(evt);
            }
        });
        jPanel2.add(pwbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 130, 30));

        typebox.setFont(new java.awt.Font("Lucida Bright", 0, 14)); // NOI18N
        typebox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Admin", "Doctor", "Receptionist", "Pharmacist" }));
        jPanel2.add(typebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 130, -1));

        cancelbtn.setBackground(new java.awt.Color(204, 0, 51));
        cancelbtn.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        cancelbtn.setForeground(new java.awt.Color(255, 255, 255));
        cancelbtn.setText("Cancel");
        cancelbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelbtnActionPerformed(evt);
            }
        });
        jPanel2.add(cancelbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 80, 30));

        loginbtn.setBackground(new java.awt.Color(204, 0, 51));
        loginbtn.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        loginbtn.setForeground(new java.awt.Color(255, 255, 255));
        loginbtn.setText("Login");
        loginbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbtnActionPerformed(evt);
            }
        });
        jPanel2.add(loginbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, 80, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 360, 250));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 300));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void unameboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unameboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_unameboxActionPerformed

    private void pwboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pwboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pwboxActionPerformed

    private void loginbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbtnActionPerformed
        
        String uname;
        String pword;
        String type;
        
        uname=unamebox.getText();
        pword =pwbox.getText();
        type =typebox.getSelectedItem().toString();
        if (unamebox.getText().isEmpty() || pwbox.getText().isEmpty() || typebox.getSelectedItem().toString().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in all required fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            String sql = "SELECT * FROM users WHERE username='"+uname+"' and password='"+pword+"' and type = '" + type + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            
             if(rs.next()){
            JOptionPane.showMessageDialog(this, "Login Successful!");

                // Open corresponding panel based on user type
                switch (type) {
                    case "Admin":
                         usersession.setUsername(uname);
                         usersession.setUserType(type);
                        new adminpanel().setVisible(true);
                        break;
                    case "Doctor":
                        usersession.setUsername(uname);
                        usersession.setUserType(type);
                        new Doctorpanel().setVisible(true);
                        break;
                    case "Receptionist":
                        usersession.setUsername(uname);
                         usersession.setUserType(type);
                        new Receptionistpanel().setVisible(true);
                         break;
                    case "Pharmacist":
                        usersession.setUsername(uname);
                         usersession.setUserType(type);
                        new Pharmacistpanel().setVisible(true);
                         break;
                   
                    default:
                        JOptionPane.showMessageDialog(this, "Unknown user type!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                }
            this.dispose();
            
        }else{
            JOptionPane.showMessageDialog(null,"username or password or type is incorrect !");
            unamebox.setText("");
            pwbox.setText("");
            typebox.setSelectedIndex(0);
            
        }
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
       
    }//GEN-LAST:event_loginbtnActionPerformed

    private void cancelbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelbtnActionPerformed
        
        int a = JOptionPane.showConfirmDialog(null, "Do you want to exit the system ", "Select",JOptionPane.YES_NO_OPTION);
        if (a==0){
            System.exit(0);
        }
    }//GEN-LAST:event_cancelbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton loginbtn;
    private javax.swing.JLabel loginlbl;
    private javax.swing.JPasswordField pwbox;
    private javax.swing.JComboBox<String> typebox;
    private javax.swing.JTextField unamebox;
    // End of variables declaration//GEN-END:variables

    
}
