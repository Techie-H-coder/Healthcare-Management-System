package view;

import java.sql.Connection;
import java.sql.PreparedStatement;
import controllers.connect;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import util.usersession;

public class DoctorView extends javax.swing.JFrame {

    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    public DoctorView() {
        initComponents();
        conn = connect.connect();
        tableload();
    }

    //THIS SELECTS ALL THE DATA FROM DB AND DISPLAYS IT
    public void tableload() {
        try {
            String sql = "SELECT doctorid AS 'Doctor ID',doctorname AS 'Doctor Name',email AS Email,contactno AS 'Contact Number',specialization AS Specialization FROM doctor";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            doctortable.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    //THIS SHOWS THE SELECTED DATA IN FIELDS
    public void tabledata() {
        int r = doctortable.getSelectedRow();

        String id = doctortable.getValueAt(r, 0).toString();
        String name = doctortable.getValueAt(r, 1).toString();
        String email = doctortable.getValueAt(r, 2).toString();
        String contactno = doctortable.getValueAt(r, 3).toString();
        String specialization = doctortable.getValueAt(r, 4).toString();

        txt_docid.setText(id);
        txt_doctorname.setText(name);
        txt_email.setText(email);
        txt_contactno.setText(contactno);
        txt_specialization.setText(specialization);
    }

    //THIISSS ISS TO SEARCHH UPP DOCTOR NAME
    public void search() {
        String search = txt_search.getText();

        try {
            String sql = "SELECT doctorid AS 'Doctor ID',doctorname AS 'Doctor Name',email AS Email,contactno AS 'Contact Number',specialization AS Specialization FROM doctor WHERE doctorname LIKE '%" + search + "%' OR doctorid LIKE '%" + search + "%'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            doctortable.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    //<-----------------------------------THISS ISS TO UPDATEEE DATAAAa----------------------------->
    public void update() {
        String id = txt_docid.getText();
        String doctorname = txt_doctorname.getText();
        String email = txt_email.getText();
        String contactno = txt_contactno.getText();
        String specialization = txt_specialization.getText();
        if (id != "ID") {

            if (doctorname.isEmpty() || email.isEmpty() || contactno.isEmpty() || specialization.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                return;
            }

            if (!isValidEmail(email)) {
                JOptionPane.showMessageDialog(null, "Invalid email format. Please enter a valid email.");
                return;
            }

            if (!isValidContactNumber(contactno)) {
                JOptionPane.showMessageDialog(null, "Invalid contact number format. It should be 10 digits.");
                return;
            }

            try {
                String sql = "UPDATE doctor SET doctorname='" + doctorname + "', email='" + email + "', contactno='" + contactno + "', specialization='" + specialization + "' WHERE doctorid='" + id + "'";
                pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Updated Successfully");
                clear();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error updating: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "No record has been chosen");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        doctortable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_email = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_doctorname = new javax.swing.JTextField();
        txt_contactno = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lbl_doctorid = new javax.swing.JLabel();
        txt_docid = new javax.swing.JLabel();
        txt_specialization = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_search = new javax.swing.JTextField();
        txt_delete = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        txt_exit = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btn_add = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(java.awt.Color.black);

        jPanel2.setBackground(new java.awt.Color(33, 33, 37));

        doctortable.setBackground(new java.awt.Color(18, 13, 49));
        doctortable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        doctortable.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        doctortable.setForeground(java.awt.Color.white);
        doctortable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Doctor ID", "Doctor's Name", "Email", "ContactNo", "Specialization"
            }
        ));
        doctortable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doctortableMouseClicked(evt);
            }
        });
        doctortable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                doctortableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(doctortable);

        jPanel1.setBackground(new java.awt.Color(33, 33, 37));
        jPanel1.setForeground(new java.awt.Color(222, 222, 222));

        jLabel2.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(222, 222, 222));
        jLabel2.setText("Full Name:");

        txt_email.setBackground(new java.awt.Color(18, 13, 49));
        txt_email.setForeground(java.awt.Color.white);
        txt_email.setToolTipText("Email");
        txt_email.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 1)));
        txt_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_emailActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(222, 222, 222));
        jLabel3.setText("Email:");

        txt_doctorname.setBackground(new java.awt.Color(18, 13, 49));
        txt_doctorname.setForeground(java.awt.Color.white);
        txt_doctorname.setToolTipText("Full Name");
        txt_doctorname.setAlignmentX(1.0F);
        txt_doctorname.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 1)));
        txt_doctorname.setDisabledTextColor(java.awt.Color.white);
        txt_doctorname.setFocusTraversalPolicyProvider(true);
        txt_doctorname.setMargin(null);
        txt_doctorname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_doctornameActionPerformed(evt);
            }
        });

        txt_contactno.setBackground(new java.awt.Color(18, 13, 49));
        txt_contactno.setForeground(java.awt.Color.white);
        txt_contactno.setToolTipText("Contact No");
        txt_contactno.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 1)));
        txt_contactno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_contactnoActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(222, 222, 222));
        jLabel4.setText("Contact No:");

        jLabel5.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(222, 222, 222));
        jLabel5.setText("Specialization:");

        lbl_doctorid.setFont(new java.awt.Font("Century Gothic", 1, 20)); // NOI18N
        lbl_doctorid.setForeground(java.awt.Color.white);
        lbl_doctorid.setText("Doctor ID");

        txt_docid.setFont(new java.awt.Font("Century Gothic", 1, 20)); // NOI18N
        txt_docid.setForeground(java.awt.Color.white);
        txt_docid.setText("ID");

        txt_specialization.setBackground(new java.awt.Color(18, 13, 49));
        txt_specialization.setForeground(java.awt.Color.white);
        txt_specialization.setToolTipText("Specialization");
        txt_specialization.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 1)));
        txt_specialization.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_specializationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_contactno, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_specialization)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(lbl_doctorid, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(44, 44, 44)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_email)
                            .addComponent(txt_doctorname, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_docid, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_doctorid, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_docid))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_doctorname, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(txt_email, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_contactno, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_specialization, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8))
        );

        jLabel1.setFont(new java.awt.Font("Century Gothic", 1, 48)); // NOI18N
        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Doctor Details");

        jLabel6.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(222, 222, 222));
        jLabel6.setText("Search Name:");

        txt_search.setBackground(new java.awt.Color(18, 13, 49));
        txt_search.setForeground(java.awt.Color.white);
        txt_search.setToolTipText("Doctor Name/ID");
        txt_search.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 1)));
        txt_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_searchActionPerformed(evt);
            }
        });
        txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_searchKeyReleased(evt);
            }
        });

        txt_delete.setBackground(java.awt.Color.red);
        txt_delete.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        txt_delete.setText("Delete");
        txt_delete.setAlignmentY(0.0F);
        txt_delete.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        txt_delete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        txt_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_deleteActionPerformed(evt);
            }
        });

        btn_update.setBackground(java.awt.Color.orange);
        btn_update.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btn_update.setText("Update");
        btn_update.setAlignmentY(0.0F);
        btn_update.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        btn_update.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        txt_exit.setBackground(java.awt.Color.black);
        txt_exit.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        txt_exit.setForeground(java.awt.Color.white);
        txt_exit.setText("Exit");
        txt_exit.setAlignmentY(0.0F);
        txt_exit.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        txt_exit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        txt_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_exitActionPerformed(evt);
            }
        });

        jButton2.setBackground(java.awt.Color.darkGray);
        jButton2.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jButton2.setText("Clear");
        jButton2.setAlignmentY(0.0F);
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btn_add.setBackground(java.awt.Color.green);
        btn_add.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btn_add.setText("Add");
        btn_add.setAlignmentY(0.0F);
        btn_add.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 1, 1)));
        btn_add.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(btn_add, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txt_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txt_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 813, Short.MAX_VALUE)
                        .addGap(41, 41, 41))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(323, 323, 323)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_add, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(72, 72, 72))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailActionPerformed

    private void txt_doctornameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_doctornameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_doctornameActionPerformed

    private void txt_contactnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_contactnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_contactnoActionPerformed

    private void txt_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_searchActionPerformed

    //<---------------------------Input validation Methodss--------------------------------->
    private boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        int atIndex = email.indexOf('@');
        int dotIndex = email.lastIndexOf('.');

        return atIndex > 0 && dotIndex > atIndex + 1 && dotIndex < email.length() - 1;
    }

    private boolean isValidContactNumber(String contactno) {
        if (contactno == null || contactno.length() != 10) {
            return false; // Must be exactly 10 digits
        }
        for (char c : contactno.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    //<------------------------------------------------------------>
    //TOO CLEARRR FIEELDDSSS
    public void clear() {
        txt_docid.setText("ID");
        txt_search.setText("");
        txt_doctorname.setText("");
        txt_email.setText("");
        txt_search.setText("");
        txt_contactno.setText("");
        txt_specialization.setText("");
    }
    private void doctortableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doctortableMouseClicked

        tabledata();
    }//GEN-LAST:event_doctortableMouseClicked

    private void doctortableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_doctortableKeyReleased
        tabledata();        // TODO add your handling code here:
    }//GEN-LAST:event_doctortableKeyReleased

    private void txt_specializationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_specializationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_specializationActionPerformed

    private void txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_searchKeyReleased
        search();
    }//GEN-LAST:event_txt_searchKeyReleased

    private void txt_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_deleteActionPerformed
        String id = txt_docid.getText();
        if (id != "ID") {
            int check = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete Doctor with ID '" + id + "'");

            if (check == 0) {
                try {
                    String sql = "DELETE from doctor WHERE doctorid='" + id + "'";
                    pst = conn.prepareStatement(sql);
                    pst.execute();
                    JOptionPane.showMessageDialog(null, "Deleted Successfully");
                    clear();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Error Deleting");
                }
            }
            tableload();
        } else {
            JOptionPane.showMessageDialog(null, "No Record has been chosen");
        }
    }//GEN-LAST:event_txt_deleteActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        update();
        tableload();

    }//GEN-LAST:event_btn_updateActionPerformed

    private void txt_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_exitActionPerformed

        String usertype =usersession.getUserType();
        
      
        switch (usertype) {
            case "Receptionist":
                this.dispose();
                new Receptionistpanel().setVisible(true);
                break;
            case "Admin":
                this.dispose();
                new adminpanel().setVisible(true);
                break;
             case "Doctor":
                 this.dispose();
                new Doctorpanel().setVisible(true);
                break;
            default:
                JOptionPane.showMessageDialog(this, "Unknown user type.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
            
            
   
    }//GEN-LAST:event_txt_exitActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        clear();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
        String doctorname;
        String email;
        String contactno;
        String specialization;

        doctorname = txt_doctorname.getText();
        email = txt_email.getText();
        contactno = txt_contactno.getText();
        specialization = txt_specialization.getText();

        if (doctorname.isEmpty() || email.isEmpty() || contactno.isEmpty() || specialization.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill in all fields.");
            return;
        }

// Validating Email
        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(null, "Invalid email format. Please enter a valid email.");
            return;
        }

// Validate Contact No
        if (!isValidContactNumber(contactno)) {
            JOptionPane.showMessageDialog(null, "Invalid contact number format. It should be 10 digits.");
            return;
        }

        try {
            // Check if the email already exists
            String checkEmailSql = "SELECT * FROM doctor WHERE email = ?";
            pst = conn.prepareStatement(checkEmailSql);
            pst.setString(1, email);
            ResultSet rsEmail = pst.executeQuery();

            if (rsEmail.next()) {
                JOptionPane.showMessageDialog(null, "Email is already taken. Please use a different email.");
                return;
            }

            // Check if the contact number already exists
            String checkContactNoSql = "SELECT * FROM doctor WHERE contactno = ?";
            pst = conn.prepareStatement(checkContactNoSql);
            pst.setString(1, contactno);
            ResultSet rsContactNo = pst.executeQuery();

            if (rsContactNo.next()) {
                JOptionPane.showMessageDialog(null, "Contact number is already taken. Please use a different contact number.");
                return;
            }

            // If there are no erros,it must proceed with the process
            String sql = "INSERT INTO doctor (doctorname, email, contactno, specialization) VALUES (?, ?, ?, ?)";
            pst = conn.prepareStatement(sql);
            pst.setString(1, doctorname);
            pst.setString(2, email);
            pst.setString(3, contactno);
            pst.setString(4, specialization);

            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Inserted Successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error with Inserting: " + e.getMessage());
        }

        tableload();
        clear();
    }//GEN-LAST:event_btn_addActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DoctorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DoctorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DoctorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DoctorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DoctorView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_add;
    private javax.swing.JButton btn_update;
    private javax.swing.JTable doctortable;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_doctorid;
    private javax.swing.JTextField txt_contactno;
    private javax.swing.JButton txt_delete;
    private javax.swing.JLabel txt_docid;
    private javax.swing.JTextField txt_doctorname;
    private javax.swing.JTextField txt_email;
    private javax.swing.JButton txt_exit;
    private javax.swing.JTextField txt_search;
    private javax.swing.JTextField txt_specialization;
    // End of variables declaration//GEN-END:variables
}
