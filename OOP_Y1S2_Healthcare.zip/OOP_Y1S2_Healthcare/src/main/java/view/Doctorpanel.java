package view;

import util.usersession;

public class Doctorpanel extends javax.swing.JFrame {

    private String username;

    public Doctorpanel() {
        initComponents();
        username = usersession.getUsername();
        setTitle("Doctor Panel - " + username);
        namelbl.setText("Welcome, Dr " + username + "!");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        namelbl = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        dinfobtn = new javax.swing.JButton();
        schedulebtn = new javax.swing.JButton();
        logoutbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        namelbl.setFont(new java.awt.Font("Lucida Bright", 1, 18)); // NOI18N
        namelbl.setText("WELCOME");
        jPanel1.add(namelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 210, 30));

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dinfobtn.setBackground(new java.awt.Color(255, 255, 153));
        dinfobtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        dinfobtn.setForeground(new java.awt.Color(153, 0, 0));
        dinfobtn.setText("Update Doctor Info");
        dinfobtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dinfobtnActionPerformed(evt);
            }
        });
        jPanel2.add(dinfobtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 170, 30));

        schedulebtn.setBackground(new java.awt.Color(255, 255, 153));
        schedulebtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        schedulebtn.setForeground(new java.awt.Color(153, 0, 0));
        schedulebtn.setText("Manage Schedule");
        schedulebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                schedulebtnActionPerformed(evt);
            }
        });
        jPanel2.add(schedulebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 170, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 350, 200));

        logoutbtn.setBackground(new java.awt.Color(204, 0, 0));
        logoutbtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        logoutbtn.setForeground(new java.awt.Color(255, 255, 51));
        logoutbtn.setText("Logout");
        logoutbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutbtnActionPerformed(evt);
            }
        });
        jPanel1.add(logoutbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, 90, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 300));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void logoutbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutbtnActionPerformed
        this.dispose();
        login loginobj = new login();
        loginobj.setVisible(true);
    }//GEN-LAST:event_logoutbtnActionPerformed

    private void schedulebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_schedulebtnActionPerformed
        this.dispose();
         new DoctorScheduleView().setVisible(true);
    }//GEN-LAST:event_schedulebtnActionPerformed

    private void dinfobtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dinfobtnActionPerformed
        this.dispose();
         new DoctorView().setVisible(true);
    }//GEN-LAST:event_dinfobtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Doctorpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Doctorpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Doctorpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Doctorpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Doctorpanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton dinfobtn;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton logoutbtn;
    private javax.swing.JLabel namelbl;
    private javax.swing.JButton schedulebtn;
    // End of variables declaration//GEN-END:variables
}
