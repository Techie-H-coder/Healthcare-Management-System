
package view;

import view.login;

/**
 *
 * @author Himani
 */
public class Reports extends javax.swing.JFrame {

    /**
     * Creates new form Reports
     */
    public Reports() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        reportInventory = new javax.swing.JButton();
        reportAppointment = new javax.swing.JButton();
        reportPatient = new javax.swing.JButton();
        logoutbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        reportInventory.setBackground(new java.awt.Color(255, 255, 153));
        reportInventory.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        reportInventory.setForeground(new java.awt.Color(153, 0, 0));
        reportInventory.setText("Inventory Reports");
        reportInventory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportInventoryActionPerformed(evt);
            }
        });
        jPanel2.add(reportInventory, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 190, 30));

        reportAppointment.setBackground(new java.awt.Color(255, 255, 153));
        reportAppointment.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        reportAppointment.setForeground(new java.awt.Color(153, 0, 0));
        reportAppointment.setText("Appointment Reports");
        reportAppointment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportAppointmentActionPerformed(evt);
            }
        });
        jPanel2.add(reportAppointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 190, 30));

        reportPatient.setBackground(new java.awt.Color(255, 255, 153));
        reportPatient.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        reportPatient.setForeground(new java.awt.Color(153, 0, 0));
        reportPatient.setText("Patient Report");
        reportPatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportPatientActionPerformed(evt);
            }
        });
        jPanel2.add(reportPatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 190, 30));

        logoutbtn.setBackground(new java.awt.Color(204, 0, 0));
        logoutbtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        logoutbtn.setForeground(new java.awt.Color(255, 255, 51));
        logoutbtn.setText("Logout");
        logoutbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutbtnActionPerformed(evt);
            }
        });
        jPanel2.add(logoutbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 90, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 350, 240));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void logoutbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutbtnActionPerformed
        this.dispose();
        login loginobj = new login();
        loginobj.setVisible(true);
    }//GEN-LAST:event_logoutbtnActionPerformed

    private void reportInventoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportInventoryActionPerformed
        this.dispose();
        new reportInventory(). setVisible(true);
    }//GEN-LAST:event_reportInventoryActionPerformed

    private void reportPatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportPatientActionPerformed
       this.dispose();
        new reportPatient(). setVisible(true);
    }//GEN-LAST:event_reportPatientActionPerformed

    private void reportAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportAppointmentActionPerformed
        this.dispose();
        new reportAppointment(). setVisible(true);
    }//GEN-LAST:event_reportAppointmentActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reports.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reports.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reports.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reports.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reports().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton logoutbtn;
    private javax.swing.JButton reportAppointment;
    private javax.swing.JButton reportInventory;
    private javax.swing.JButton reportPatient;
    // End of variables declaration//GEN-END:variables
}
