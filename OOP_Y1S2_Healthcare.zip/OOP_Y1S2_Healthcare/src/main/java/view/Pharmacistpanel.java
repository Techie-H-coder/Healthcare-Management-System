
package view;
import util.usersession;

public class Pharmacistpanel extends javax.swing.JFrame {

     private String username;
    public Pharmacistpanel() {
        initComponents();
         username = usersession.getUsername();
        setTitle("Pharmacist Panel - " + username);
        setLocationRelativeTo(null);
        namelbl.setText("Welcome, " + username + "!");
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        namelbl = new javax.swing.JLabel();
        logoutbtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        pharmacybtn = new javax.swing.JButton();
        notifybtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        namelbl.setBackground(new java.awt.Color(172, 244, 245));
        namelbl.setFont(new java.awt.Font("Lucida Bright", 1, 18)); // NOI18N
        namelbl.setForeground(new java.awt.Color(0, 0, 102));
        namelbl.setText("WELCOME");
        jPanel1.add(namelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 210, 30));

        logoutbtn.setBackground(new java.awt.Color(204, 0, 0));
        logoutbtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        logoutbtn.setForeground(new java.awt.Color(255, 255, 51));
        logoutbtn.setText("Logout");
        logoutbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutbtnActionPerformed(evt);
            }
        });
        jPanel1.add(logoutbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, 90, 30));

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pharmacybtn.setBackground(new java.awt.Color(255, 255, 153));
        pharmacybtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        pharmacybtn.setForeground(new java.awt.Color(153, 0, 0));
        pharmacybtn.setText("Pharmacy Inventory");
        pharmacybtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pharmacybtnActionPerformed(evt);
            }
        });
        jPanel2.add(pharmacybtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, 170, 30));

        notifybtn.setBackground(new java.awt.Color(255, 255, 153));
        notifybtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        notifybtn.setForeground(new java.awt.Color(153, 0, 0));
        notifybtn.setText("Notify low stocks");
        jPanel2.add(notifybtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 170, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 350, 200));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 300));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void logoutbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutbtnActionPerformed
        this.dispose();
        login loginobj = new login();
        loginobj.setVisible(true);
    }//GEN-LAST:event_logoutbtnActionPerformed

    private void pharmacybtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pharmacybtnActionPerformed
        this.dispose();
        new PharmacyDashboard(). setVisible(true);
    }//GEN-LAST:event_pharmacybtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pharmacistpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pharmacistpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pharmacistpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pharmacistpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pharmacistpanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton logoutbtn;
    private javax.swing.JLabel namelbl;
    private javax.swing.JButton notifybtn;
    private javax.swing.JButton pharmacybtn;
    // End of variables declaration//GEN-END:variables
}
