
package view;

import controllers.connect;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.table.TableModel;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SellMedicine extends javax.swing.JFrame {

    public String numberPattern = "^[0-9]*$";
    private int finaltotalprice = 0;
    private String billId = "";
   
    public SellMedicine() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void medicineName(String nameOrUniqueId){
        DefaultTableModel model = (DefaultTableModel) medicineTable.getModel();
        model.setRowCount(0);
        try{
            Connection con = connect.connect();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from medicine where name like '"+nameOrUniqueId+"%' or medicine_id like '"+nameOrUniqueId+"%'");
            while(rs.next()){
                model.addRow(new Object[]{rs.getString("id")+"-- "+rs.getString("medicine_id")+"-- "+rs.getString("name")});
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    private void clearmedicineFields(){
        txtmedid.setText("");
        txtname.setText("");
        txtdate.setText("");
        txtpriceperunit.setText("");
        txtnumberofunits.setText("");
        txttotalprice.setText("");
        
    }
    
    public String getUniqueId(String prefix){
        return prefix + System.nanoTime();
    }                   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtsearch = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        medicineTable = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        txtmedid = new javax.swing.JTextField();
        txtname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtpriceperunit = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtdate = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtnumberofunits = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        purchasetable = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        lbfinaltotalprice = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        exitbtn1 = new javax.swing.JButton();
        txttotalprice = new javax.swing.JTextField();
        btnaddtocart = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sell medicine");
        setUndecorated(true);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Sell Medicine");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 10, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Search");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 70, 69, 26));

        txtsearch.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtsearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtsearchKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsearchKeyReleased(evt);
            }
        });
        getContentPane().add(txtsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 70, 120, -1));

        medicineTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Medicine (ID-Med_ID-Name)"
            }
        ));
        medicineTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                medicineTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(medicineTable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 110, 210, 330));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Medicine ID");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 100, -1, -1));

        txtmedid.setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().add(txtmedid, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 122, 130, -1));

        txtname.setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().add(txtname, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 140, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Medicine Name");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, -1, -1));

        txtpriceperunit.setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().add(txtpriceperunit, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 246, 130, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Price Per Unit");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 224, -1, -1));

        txtdate.setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().add(txtdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 184, 130, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Expiry Date");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 162, -1, -1));

        txtnumberofunits.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnumberofunitsActionPerformed(evt);
            }
        });
        txtnumberofunits.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtnumberofunitsKeyReleased(evt);
            }
        });
        getContentPane().add(txtnumberofunits, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 150, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("No. of Pieces");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Total Price ");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 210, -1, 20));

        purchasetable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        purchasetable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Medicine ID", "Name", "Expiry Date", "Price Per Unit", "No.of Units", "Total Price "
            }
        ));
        purchasetable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                purchasetableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(purchasetable);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 278, 540, 210));

        jButton3.setBackground(new java.awt.Color(0, 255, 102));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton3.setText("Purchurse ");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 460, 164, 52));

        jPanel1.setBackground(new java.awt.Color(0, 102, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 102, 102));
        jLabel10.setText("Click to Remove");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 500, -1, -1));

        lbfinaltotalprice.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lbfinaltotalprice.setForeground(new java.awt.Color(0, 255, 0));
        lbfinaltotalprice.setText("00");
        jPanel1.add(lbfinaltotalprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 460, 40, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 255, 0));
        jLabel9.setText("LKR");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 460, -1, -1));

        exitbtn1.setBackground(new java.awt.Color(204, 0, 102));
        exitbtn1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        exitbtn1.setForeground(new java.awt.Color(255, 255, 204));
        exitbtn1.setText("Exit");
        exitbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbtn1ActionPerformed(evt);
            }
        });
        jPanel1.add(exitbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 10, 90, 40));
        jPanel1.add(txttotalprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 240, 140, -1));

        btnaddtocart.setBackground(new java.awt.Color(255, 255, 204));
        btnaddtocart.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        btnaddtocart.setForeground(new java.awt.Color(204, 51, 0));
        btnaddtocart.setText("ADD");
        btnaddtocart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddtocartActionPerformed(evt);
            }
        });
        jPanel1.add(btnaddtocart, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 170, 90, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 540));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtnumberofunitsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnumberofunitsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnumberofunitsActionPerformed

    private void btnaddtocartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddtocartActionPerformed
        // TODO add your handling code here:
        String noofunits = txtnumberofunits.getText();
        String uniqueId = txtmedid.getText();
        
        if(!noofunits.equals("") && !uniqueId.equals("")){
            String name = txtname.getText();
            String date = txtdate.getText();
            String priceperunit = txtpriceperunit.getText();
            String totalprice = txttotalprice.getText();
            int checkstock = 0;
            int checkmedicinealreadyexistintable = 0;
            
            try{
                Connection con = connect.connect();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("select * from medicine where medicine_id="+uniqueId+"");
                while(rs.next()){
                    if(rs.getInt("quantity")>= Integer.parseInt(noofunits)){
                        checkstock = 1;
                    }else{
                        JOptionPane.showMessageDialog(null, "Insufficent Stock. Only "+rs.getInt("quantity")+" Avalable in Stock");
                    }
                }
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
            if(checkstock == 1){
                DefaultTableModel dtm = (DefaultTableModel) purchasetable.getModel();
                if(purchasetable.getRowCount() !=0){
                    for(int i=0; i <purchasetable.getRowCount();i++){
                        if(Integer.parseInt(dtm.getValueAt(i,0).toString()) == Integer.parseInt(uniqueId)){
                            checkmedicinealreadyexistintable = 1;
                            JOptionPane.showMessageDialog(null, "Medicine already Exists in the purchase list");
                        }
                    }
                }
                if(checkmedicinealreadyexistintable == 0){
                    dtm.addRow(new Object[]{uniqueId,name,date,priceperunit,noofunits,totalprice});
                    finaltotalprice = finaltotalprice + Integer.parseInt(totalprice);
                    lbfinaltotalprice.setText(String.valueOf(finaltotalprice));
                    JOptionPane.showMessageDialog(null, "Added successfully to the purchase");
                }
                clearmedicineFields();
            }
        }else{
            JOptionPane.showMessageDialog(null, "No of Piece and Medicine ID field is Requaired");
        }
    }//GEN-LAST:event_btnaddtocartActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        if(finaltotalprice !=0){
            billId = getUniqueId("Bill-");
            
            DefaultTableModel dtm = (DefaultTableModel) purchasetable.getModel();
            if(purchasetable.getRowCount() !=0){
                for(int i=0; i<purchasetable.getRowCount(); i++){
                    try{
                        Connection con = connect.connect();
                        Statement st = con.createStatement();
                        st.executeUpdate("Update medicine set quantity = quantity - "+Integer.parseInt(dtm.getValueAt(i,4).toString())+" where medicine_id= "+Integer.parseInt(dtm.getValueAt(i, 0).toString()));
                    }
                    catch(Exception e){
                        JOptionPane.showMessageDialog(null, e);
                    }
                }
            }
            try{
                SimpleDateFormat myFormat = new SimpleDateFormat("dd-MM-yyy");
                Calendar cal = Calendar.getInstance();
                String currentTime = myFormat.format(cal.getTime());
                Connection con = connect.connect();
                PreparedStatement ps = con.prepareStatement("insert into bill(billId,billDate,totalPaid) values(?,?,?)");
                ps.setString(1,billId);
                ps.setString(2, currentTime);
                ps.setString(3, String.valueOf(finaltotalprice));
                ps.executeUpdate();
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
            setVisible(false);
            new SellMedicine().setVisible(true);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // TODO add your handling code here:
        medicineName("");
        txtmedid.setEditable(false);
        txtname.setEditable(false);
        txtdate.setEditable(false);
        txtpriceperunit.setEditable(false);
        txttotalprice.setEditable(false);
        
    }//GEN-LAST:event_formComponentShown

    private void txtsearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsearchKeyPressed

    private void txtsearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchKeyReleased
        // TODO add your handling code here:
        String search = txtsearch.getText();
        medicineName(search);
    }//GEN-LAST:event_txtsearchKeyReleased

    private void medicineTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_medicineTableMouseClicked
        // TODO add your handling code here:
        int index = medicineTable.getSelectedRow();
        TableModel model = medicineTable.getModel();
        String nameOrUniqueId = model.getValueAt(index, 0).toString();
        
        String uniqueId[] = nameOrUniqueId.split("-",0);
        try{
            Connection con = connect.connect();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from medicine where id = "+uniqueId[0]+"");
            while(rs.next()){
                txtmedid.setText(rs.getString("medicine_id"));
                txtname.setText(rs.getString("name"));
                txtdate.setText(rs.getString("expiry_date"));
                txtpriceperunit.setText(rs.getString("price"));
                txtnumberofunits.setText("");
                txttotalprice.setText("");
            }
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_medicineTableMouseClicked

    private void txtnumberofunitsKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnumberofunitsKeyReleased
        // TODO add your handling code here:
        String noofunits = txtnumberofunits.getText();
        if (!noofunits.equals("")){
            String price = txtpriceperunit.getText();
            if(!noofunits.matches(numberPattern)){
                JOptionPane.showMessageDialog(null,"Number of Pieces field is invaild");
                txtnumberofunits.setText("");

            }
            int totalPrice = Integer.parseInt(noofunits) * Integer.parseInt(price);
            txttotalprice.setText(String.valueOf(totalPrice));
        }else{
            txttotalprice.setText("");
        }
    }//GEN-LAST:event_txtnumberofunitsKeyReleased

    private void purchasetableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_purchasetableMouseClicked
        // TODO add your handling code here:
        int index = purchasetable.getSelectedRow();
        int a = JOptionPane.showConfirmDialog(null, "Do you want to remove this medicine from the list","Select", JOptionPane.YES_NO_OPTION);
        if(a == 0){
            TableModel model = purchasetable.getModel();
            String total = model.getValueAt(index, 5).toString();
            finaltotalprice = finaltotalprice - Integer.parseInt(total);
            lbfinaltotalprice.setText(String.valueOf(finaltotalprice));
            ((DefaultTableModel) purchasetable.getModel()).removeRow(index);
        }
    }//GEN-LAST:event_purchasetableMouseClicked

    private void exitbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbtn1ActionPerformed
        this.dispose();
        new PharmacyDashboard().setVisible(true);
    }//GEN-LAST:event_exitbtn1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SellMedicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SellMedicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SellMedicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SellMedicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SellMedicine().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnaddtocart;
    private javax.swing.JButton exitbtn1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbfinaltotalprice;
    private javax.swing.JTable medicineTable;
    private javax.swing.JTable purchasetable;
    private javax.swing.JTextField txtdate;
    private javax.swing.JTextField txtmedid;
    private javax.swing.JTextField txtname;
    private javax.swing.JTextField txtnumberofunits;
    private javax.swing.JTextField txtpriceperunit;
    private javax.swing.JTextField txtsearch;
    private javax.swing.JTextField txttotalprice;
    // End of variables declaration//GEN-END:variables
}
