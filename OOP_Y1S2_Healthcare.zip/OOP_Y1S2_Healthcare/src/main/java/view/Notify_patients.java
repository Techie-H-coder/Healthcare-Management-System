
package view;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

public class Notify_patients {

    private static final String SMTP_HOST = "http://web-apac-sg-1.curtcreation.net/";
    private static final String SMTP_PORT = "587";
    private static final String SMTP_AUTH = "true";
    private static final String SMTP_STARTTLS = "true";

    private static final String USERNAME = "test-oop@divinerp.net";
    private static final String PASSWORD = "IZeh22ROASUTC";

    private static Session session;

    static {
        Properties props = new Properties();
        props.put("mail.smtp.auth", SMTP_AUTH);
        props.put("mail.smtp.starttls.enable", SMTP_STARTTLS);
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);

        session = Session.getInstance(props,
            new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(USERNAME, PASSWORD);
                }
            });
    }

    public static void sendAppointmentConfirmation(String toEmail, String patientName, String doctorName, String date, String time) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME, "Healthcare Support"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject("Appointment Confirmation");

            String msgContent = "Dear " + patientName + ",\n\n"
                    + "Your appointment has been confirmed.\n\n"
                    + "Doctor: " + doctorName + "\n"
                    + "Date: " + date + "\n"
                    + "Time: " + time + "\n\n"
                    + "Please arrive on time. Thank you!";

            message.setText(msgContent);
            Transport.send(message);
            JOptionPane.showMessageDialog(null, "Appointment confirmation email sent successfully to " + toEmail);
            
        } catch (MessagingException | java.io.UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public static void sendAppointmentReminder(String toEmail, String patientName, String doctorName, String date, String time) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME, "Healthcare Support"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject("Appointment Reminder");

            String msgContent = "Dear " + patientName + ",\n\n"
                    + "This is a reminder for your upcoming appointment.\n\n"
                    + "Doctor: " + doctorName + "\n"
                    + "Date: " + date + "\n"
                    + "Time: " + time + "\n\n"
                    + "Please make sure to be on time. Thank you!";

            message.setText(msgContent);
            Transport.send(message);

            System.out.println("Appointment reminder email sent successfully to " + toEmail);
        } catch (MessagingException | java.io.UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public static void sendTestResults(String toEmail, String patientName, String testName, String result) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME, "Healthcare Support"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject("Test Results");

            String msgContent = "Dear " + patientName + ",\n\n"
                    + "Your test results are now available.\n\n"
                    + "Test: " + testName + "\n"
                    + "Result: " + result + "\n\n"
                    + "Please consult with your doctor for further details.";

            message.setText(msgContent);
            Transport.send(message);

            System.out.println("Test results email sent successfully to " + toEmail);
        } catch (MessagingException | java.io.UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public static void sendPrescriptionNotification(String toEmail, String patientName, String medicine, String dosage) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME, "Healthcare Support"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject("Prescription Notification");

            String msgContent = "Dear " + patientName + ",\n\n"
                    + "A new prescription has been issued for you.\n\n"
                    + "Medicine: " + medicine + "\n"
                    + "Dosage: " + dosage + "\n\n"
                    + "Please follow your doctor's instructions carefully.";

            message.setText(msgContent);
            Transport.send(message);

            System.out.println("Prescription notification email sent successfully to " + toEmail);
        } catch (MessagingException | java.io.UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public static void sendFollowUpReminder(String toEmail, String patientName, String doctorName, String date) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME, "Healthcare Support"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject("Follow-Up Reminder");

            String msgContent = "Dear " + patientName + ",\n\n"
                    + "This is a reminder for your follow-up appointment.\n\n"
                    + "Doctor: " + doctorName + "\n"
                    + "Date: " + date + "\n\n"
                    + "Please ensure to attend on time.";

            message.setText(msgContent);
            Transport.send(message);

            System.out.println("Follow-up reminder email sent successfully to " + toEmail);
        } catch (MessagingException | java.io.UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }
}

