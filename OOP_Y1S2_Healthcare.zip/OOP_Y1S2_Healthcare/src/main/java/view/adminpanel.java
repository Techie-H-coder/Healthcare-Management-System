
package view;
import util.usersession;
public class adminpanel extends javax.swing.JFrame {

   private String username;
    public adminpanel() {
        initComponents();
        username = usersession.getUsername();
        setTitle("Admin Panel - " + username);
        namelbl.setText("Welcome, " + username + "!");
        
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        namelbl = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        pinfobtn = new javax.swing.JButton();
        pharmacybtn = new javax.swing.JButton();
        dinfobtn = new javax.swing.JButton();
        reportsbtn = new javax.swing.JButton();
        logoutbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(102, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        namelbl.setBackground(new java.awt.Color(172, 244, 245));
        namelbl.setFont(new java.awt.Font("Lucida Bright", 1, 18)); // NOI18N
        namelbl.setForeground(new java.awt.Color(0, 0, 102));
        namelbl.setText("WELCOME");
        jPanel1.add(namelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 210, 30));

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pinfobtn.setBackground(new java.awt.Color(255, 255, 153));
        pinfobtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        pinfobtn.setForeground(new java.awt.Color(153, 0, 0));
        pinfobtn.setText("Patient info");
        pinfobtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pinfobtnActionPerformed(evt);
            }
        });
        jPanel2.add(pinfobtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 150, 170, 30));

        pharmacybtn.setBackground(new java.awt.Color(255, 255, 153));
        pharmacybtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        pharmacybtn.setForeground(new java.awt.Color(153, 0, 0));
        pharmacybtn.setText("Pharmacy Inventory");
        pharmacybtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pharmacybtnActionPerformed(evt);
            }
        });
        jPanel2.add(pharmacybtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, 170, 30));

        dinfobtn.setBackground(new java.awt.Color(255, 255, 153));
        dinfobtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        dinfobtn.setForeground(new java.awt.Color(153, 0, 0));
        dinfobtn.setText("Doctor Info");
        dinfobtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dinfobtnActionPerformed(evt);
            }
        });
        jPanel2.add(dinfobtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 170, 30));

        reportsbtn.setBackground(new java.awt.Color(255, 255, 153));
        reportsbtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        reportsbtn.setForeground(new java.awt.Color(153, 0, 0));
        reportsbtn.setText("Generate Reports");
        reportsbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportsbtnActionPerformed(evt);
            }
        });
        jPanel2.add(reportsbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 170, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 350, 200));

        logoutbtn.setBackground(new java.awt.Color(204, 0, 0));
        logoutbtn.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        logoutbtn.setForeground(new java.awt.Color(255, 255, 51));
        logoutbtn.setText("Logout");
        logoutbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutbtnActionPerformed(evt);
            }
        });
        jPanel1.add(logoutbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 20, 90, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 422, 310));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void logoutbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutbtnActionPerformed
         this.dispose();
        login loginobj = new login();
        loginobj.setVisible(true);
    }//GEN-LAST:event_logoutbtnActionPerformed

    private void reportsbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportsbtnActionPerformed
        this.dispose();
        new Reports().setVisible(true);
    }//GEN-LAST:event_reportsbtnActionPerformed

    private void pharmacybtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pharmacybtnActionPerformed
        this.dispose();
        new PharmacyDashboard().setVisible(true);
    }//GEN-LAST:event_pharmacybtnActionPerformed

    private void dinfobtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dinfobtnActionPerformed
        this.dispose();
        new DoctorView().setVisible(true);
    }//GEN-LAST:event_dinfobtnActionPerformed

    private void pinfobtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pinfobtnActionPerformed
         this.dispose();
        new patientinfo().setVisible(true);
    }//GEN-LAST:event_pinfobtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(adminpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(adminpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(adminpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(adminpanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new adminpanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton dinfobtn;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton logoutbtn;
    private javax.swing.JLabel namelbl;
    private javax.swing.JButton pharmacybtn;
    private javax.swing.JButton pinfobtn;
    private javax.swing.JButton reportsbtn;
    // End of variables declaration//GEN-END:variables
}
