
package view;
import controllers.ReportController;
import java.util.ArrayList;
import java.util.HashMap;
import view.Reports;

public class reportAppointment extends javax.swing.JFrame {

    ReportController reportController;
    /**
     * Creates new form reportAppointment
     */
    public reportAppointment() {
        initComponents();
        reportController = new ReportController();
        feedData();
    }
    
    private void feedData(){
        int pendingCount = reportController.getAppointmentCountByStatus("Pending");
        int scheduledCount = reportController.getAppointmentCountByStatus("Scheduled");
        int confirmedCount = reportController.getAppointmentCountByStatus("Confirmed");
        
        pending_appointments1.setText(pendingCount + "");
        scheduled_appointments.setText(scheduledCount + "");
        confirmed_appointments.setText(confirmedCount + "");
        
        ArrayList<HashMap<String, Object>> appointmentList = reportController.getAllAppointments();
    
        String[] columns = {"ID", "Patient Name", "Email", "Doctor ID", "Doctor Name", "Date", "Time", "Department", "Status"};
        Object[][] data = new Object[appointmentList.size()][columns.length];

        for (int i = 0; i < appointmentList.size(); i++) {
            HashMap<String, Object> appointment = appointmentList.get(i);
            data[i][0] = appointment.get("id");
            data[i][1] = appointment.get("pname");
            data[i][2] = appointment.get("email");
            data[i][3] = appointment.get("did");
            data[i][4] = appointment.get("dname");
            data[i][5] = appointment.get("date");
            data[i][6] = appointment.get("time");
            data[i][7] = appointment.get("dept");
            data[i][8] = appointment.get("status");
        }

        jTable_Appointments.setModel(new javax.swing.table.DefaultTableModel(data, columns));
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        scheduled_appointments = new javax.swing.JLabel();
        pending_appointments1 = new javax.swing.JLabel();
        confirmed_appointments = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Appointments = new javax.swing.JTable();
        backBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Appointment Report");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel1.setText("Appointment Report");

        jLabel2.setText("Pending Appointments");

        jLabel3.setText("Scheduled Appointments");

        jLabel4.setText("Confirmed Appointments");

        scheduled_appointments.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        scheduled_appointments.setText("0");

        pending_appointments1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        pending_appointments1.setText("0");

        confirmed_appointments.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        confirmed_appointments.setText("0");

        jTable_Appointments.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable_Appointments);

        backBtn.setText("Back");
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jLabel2)
                .addGap(191, 191, 191)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 172, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(81, 81, 81))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(backBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(279, 279, 279))
            .addGroup(layout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addComponent(pending_appointments1)
                .addGap(313, 313, 313)
                .addComponent(scheduled_appointments)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(confirmed_appointments)
                .addGap(139, 139, 139))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(backBtn)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(scheduled_appointments)
                    .addComponent(pending_appointments1)
                    .addComponent(confirmed_appointments))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnActionPerformed
        this.dispose();
        new Reports().setVisible(true);
    }//GEN-LAST:event_backBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(reportAppointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(reportAppointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(reportAppointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(reportAppointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new reportAppointment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBtn;
    private javax.swing.JLabel confirmed_appointments;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Appointments;
    private javax.swing.JLabel pending_appointments1;
    private javax.swing.JLabel scheduled_appointments;
    // End of variables declaration//GEN-END:variables
}
