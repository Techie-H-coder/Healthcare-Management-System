
package util;

public class usersession {

    private static String username;
    private static String utype;

    
    public static void setUsername(String uname) {
        username = uname;
    }
    public static void setUserType(String type) {
        utype= type;
    }

    public static String getUsername() {
        return username;
    }
    public static String getUserType() {
        return utype;
    }
}

    

