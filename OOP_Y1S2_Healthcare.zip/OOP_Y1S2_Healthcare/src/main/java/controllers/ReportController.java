package controllers;

import controllers.connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

public class ReportController {

    public ArrayList<HashMap<String, Object>> getLowStockMedicines() {
        ArrayList<HashMap<String, Object>> medicineList = new ArrayList<>();
        String query = "SELECT id, name, medicine_id, quantity, price FROM medicine WHERE quantity < 5";
        
        try (Connection conn = connect.connect(); 
             PreparedStatement pstmt = conn.prepareStatement(query); 
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                HashMap<String, Object> medicine = new HashMap<>();
                medicine.put("id", rs.getInt("id"));
                medicine.put("name", rs.getString("name"));
                medicine.put("medicine_id", rs.getString("medicine_id"));
                medicine.put("quantity", rs.getInt("quantity"));
                medicine.put("price", rs.getDouble("price"));
                medicineList.add(medicine);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return medicineList;
    }

    public ArrayList<HashMap<String, Object>> getExpensiveMedicines() {
        ArrayList<HashMap<String, Object>> medicineList = new ArrayList<>();
        String query = "SELECT id, name, medicine_id, quantity, price FROM medicine WHERE price > 10000";
        
        try (Connection conn = connect.connect(); 
             PreparedStatement pstmt = conn.prepareStatement(query); 
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                HashMap<String, Object> medicine = new HashMap<>();
                medicine.put("id", rs.getInt("id"));
                medicine.put("name", rs.getString("name"));
                medicine.put("medicine_id", rs.getString("medicine_id"));
                medicine.put("quantity", rs.getInt("quantity"));
                medicine.put("price", rs.getDouble("price"));
                medicineList.add(medicine);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return medicineList;
    }
    
    public String getAgeBasedCountByBloodType() {
        int above18 = 0;
        int below18 = 0;
        String query = "SELECT age FROM patient WHERE 1";

        try (Connection conn = connect.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                int age = rs.getInt("age");
                if (age >= 18) {
                    above18++;
                } else {
                    below18++;
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        return "Above 18 age we have " + above18 + " patients, Below 18 we have " + below18 + " patients";
    }
    
    public int getCountByBloodType(String bloodType) {
        int count = 0;
        String query = "SELECT COUNT(*) FROM patient WHERE bloodtype = ?";

        try (Connection conn = connect.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, bloodType);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                count = rs.getInt(1);  
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        return count;
    }
    
    public ArrayList<HashMap<String, Object>> getAllAppointments() {
        ArrayList<HashMap<String, Object>> appointmentList = new ArrayList<>();
        String query = "SELECT id, pid, pname, email, did, dname, date, time, dept, status FROM appointment";

        try (Connection conn = connect.connect();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                HashMap<String, Object> appointment = new HashMap<>();
                appointment.put("id", rs.getInt("id"));
                appointment.put("pid", rs.getInt("pid"));
                appointment.put("pname", rs.getString("pname"));
                appointment.put("email", rs.getString("email"));
                appointment.put("did", rs.getInt("did"));
                appointment.put("dname", rs.getString("dname"));
                appointment.put("date", rs.getString("date"));
                appointment.put("time", rs.getString("time"));
                appointment.put("dept", rs.getString("dept"));
                appointment.put("status", rs.getString("status"));
                appointmentList.add(appointment);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return appointmentList;
    }

    
    public int getAppointmentCountByStatus(String status) {
        int count = 0;
        String query = "SELECT COUNT(*) FROM appointment WHERE status = ?";

        try (Connection conn = connect.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, status);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                count = rs.getInt(1);  
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        return count;
    }
}
